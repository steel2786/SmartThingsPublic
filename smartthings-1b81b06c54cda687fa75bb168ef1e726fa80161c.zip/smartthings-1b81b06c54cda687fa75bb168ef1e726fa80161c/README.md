# smartthings

My Smartthings stuff, you can find readme in each folders describing what's inside.
